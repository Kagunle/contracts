// SPDX-License-Identifier: MIT
pragma solidity 0.8.15;

// Testing
import { console2 as console } from "lib/forge-std/src/console2.sol";
import { Vm, VmSafe } from "lib/forge-std/src/Vm.sol";
import { EIP1967Helper } from "test/mocks/EIP1967Helper.sol";
import { FeatureFlags } from "test/setup/FeatureFlags.sol";

// Scripts
import { SystemDeploy } from "scripts/deploy/SystemDeploy.s.sol";
import { ForkLive } from "test/setup/ForkLive.s.sol";
import { LATEST_FORK } from "scripts/libraries/Config.sol";
import { L2Genesis } from "scripts/L2Genesis.s.sol";
import { Fork, ForkUtils } from "scripts/libraries/Config.sol";
import { Artifacts } from "scripts/Artifacts.s.sol";
import { DeployUtils } from "scripts/libraries/DeployUtils.sol";
import { Config } from "scripts/libraries/Config.sol";

// Libraries
import { Predeploys } from "src/libraries/Predeploys.sol";
import { Preinstalls } from "src/libraries/Preinstalls.sol";
import { AddressAliasHelper } from "src/vendor/AddressAliasHelper.sol";

// Interfaces
import { IOptimismPortal2 as IOptimismPortal } from "interfaces/L1/IOptimismPortal2.sol";
import { IETHLockbox } from "interfaces/L1/IETHLockbox.sol";
import { IL1CrossDomainMessenger } from "interfaces/L1/IL1CrossDomainMessenger.sol";
import { ISystemConfig } from "interfaces/L1/ISystemConfig.sol";
import { ISuperchainConfig } from "interfaces/L1/ISuperchainConfig.sol";
import { IL1StandardBridge } from "interfaces/L1/IL1StandardBridge.sol";
import { IL1ERC721Bridge } from "interfaces/L1/IL1ERC721Bridge.sol";
import { IOptimismMintableERC721Factory } from "interfaces/L2/IOptimismMintableERC721Factory.sol";
import { IDisputeGameFactory } from "interfaces/L1/proofs/IDisputeGameFactory.sol";
import { IDelayedWETH } from "interfaces/L1/proofs/IDelayedWETH.sol";
import { IAnchorStateRegistry } from "interfaces/L1/proofs/IAnchorStateRegistry.sol";
import { IBigStepper } from "interfaces/L1/proofs/IBigStepper.sol";
import { IL2CrossDomainMessenger } from "interfaces/L2/IL2CrossDomainMessenger.sol";
import { IL2StandardBridge } from "interfaces/L2/IL2StandardBridge.sol";
import { IL2ToL1MessagePasser } from "interfaces/L2/IL2ToL1MessagePasser.sol";
import { IL2ERC721Bridge } from "interfaces/L2/IL2ERC721Bridge.sol";
import { IOptimismMintableERC20Factory } from "interfaces/universal/IOptimismMintableERC20Factory.sol";
import { IAddressManager } from "interfaces/legacy/IAddressManager.sol";
import { IBaseFeeVault } from "interfaces/L2/IBaseFeeVault.sol";
import { ISequencerFeeVault } from "interfaces/L2/ISequencerFeeVault.sol";
import { IL1FeeVault } from "interfaces/L2/IL1FeeVault.sol";
import { IOperatorFeeVault } from "interfaces/L2/IOperatorFeeVault.sol";
import { IGasPriceOracle } from "interfaces/L2/IGasPriceOracle.sol";
import { IL1Block } from "interfaces/L2/IL1Block.sol";
import { IProxyAdmin } from "interfaces/universal/IProxyAdmin.sol";
import { IWETH98 } from "interfaces/universal/IWETH98.sol";
import { IPermissionedDisputeGameV2 } from "interfaces/L1/proofs/v2/IPermissionedDisputeGameV2.sol";
import { IFaultDisputeGameV2 } from "interfaces/L1/proofs/v2/IFaultDisputeGameV2.sol";
import { IVerifier } from "interfaces/L1/proofs/IVerifier.sol";
import { TEEProverRegistry } from "src/L1/proofs/tee/TEEProverRegistry.sol";

/// @title Setup
/// @dev This contact is responsible for setting up the contracts in state. It currently
///      sets the L2 contracts directly at the predeploy addresses instead of setting them
///      up behind proxies. In the future we will migrate to importing the genesis JSON
///      file that is created to set up the L2 contracts instead of setting them up manually.
abstract contract Setup is FeatureFlags {
    using ForkUtils for Fork;

    /// @notice The address of the foundry Vm contract.
    Vm private constant vm = Vm(0x7109709ECfa91a80626fF3989D68f67F5b1DD12D);

    uint256 internal constant ETH_MAINNET_CHAIN_ID = 1;
    uint256 internal constant ETH_SEPOLIA_CHAIN_ID = 11155111;

    /// @notice The address of the SystemDeploy contract. Set into state with `etch` to avoid
    ///         mutating any nonces. MUST not have constructor logic.
    SystemDeploy internal constant deploy =
        SystemDeploy(address(uint160(uint256(keccak256(abi.encode("optimism.deploy"))))));

    /// @notice The address of the ForkLive contract. Set into state with `etch` to avoid
    ///         mutating any nonces. MUST not have constructor logic.
    ForkLive internal constant forkLive =
        ForkLive(address(uint160(uint256(keccak256(abi.encode("optimism.forklive"))))));

    /// @notice The address of the Artifacts contract. Set into state by SystemDeploy.setUp() with `etch` to avoid
    ///         mutating any nonces. MUST not have constructor logic.
    Artifacts public constant artifacts =
        Artifacts(address(uint160(uint256(keccak256(abi.encode("optimism.artifacts"))))));

    L2Genesis internal constant l2Genesis =
        L2Genesis(address(uint160(uint256(keccak256(abi.encode("optimism.l2genesis"))))));

    /// @notice Allows users of Setup to override what L2 genesis is being created.
    Fork l2Fork = LATEST_FORK;

    // L1 contracts - dispute
    IDisputeGameFactory disputeGameFactory;
    IAnchorStateRegistry anchorStateRegistry;
    IFaultDisputeGameV2 faultDisputeGame;
    IDelayedWETH delayedWeth;
    IPermissionedDisputeGameV2 permissionedDisputeGame;
    IDelayedWETH delayedWETHPermissionedGameProxy;

    // L1 contracts - core
    address proxyAdminOwner;
    IProxyAdmin proxyAdmin;
    address superchainProxyAdminOwner;
    IProxyAdmin superchainProxyAdmin;
    IOptimismPortal optimismPortal2;
    IETHLockbox ethLockbox;
    ISystemConfig systemConfig;
    IL1StandardBridge l1StandardBridge;
    IL1CrossDomainMessenger l1CrossDomainMessenger;
    IAddressManager addressManager;
    IL1ERC721Bridge l1ERC721Bridge;
    IOptimismMintableERC20Factory l1OptimismMintableERC20Factory;
    ISuperchainConfig superchainConfig;
    IBigStepper mips;

    // L2 contracts
    IL2CrossDomainMessenger l2CrossDomainMessenger =
        IL2CrossDomainMessenger(payable(Predeploys.L2_CROSS_DOMAIN_MESSENGER));
    IL2StandardBridge l2StandardBridge = IL2StandardBridge(payable(Predeploys.L2_STANDARD_BRIDGE));
    IL2ToL1MessagePasser l2ToL1MessagePasser = IL2ToL1MessagePasser(payable(Predeploys.L2_TO_L1_MESSAGE_PASSER));
    IOptimismMintableERC20Factory l2OptimismMintableERC20Factory =
        IOptimismMintableERC20Factory(Predeploys.OPTIMISM_MINTABLE_ERC20_FACTORY);
    IL2ERC721Bridge l2ERC721Bridge = IL2ERC721Bridge(Predeploys.L2_ERC721_BRIDGE);
    IOptimismMintableERC721Factory l2OptimismMintableERC721Factory =
        IOptimismMintableERC721Factory(Predeploys.OPTIMISM_MINTABLE_ERC721_FACTORY);
    IBaseFeeVault baseFeeVault = IBaseFeeVault(payable(Predeploys.BASE_FEE_VAULT));
    ISequencerFeeVault sequencerFeeVault = ISequencerFeeVault(payable(Predeploys.SEQUENCER_FEE_WALLET));
    IL1FeeVault l1FeeVault = IL1FeeVault(payable(Predeploys.L1_FEE_VAULT));
    IOperatorFeeVault operatorFeeVault = IOperatorFeeVault(payable(Predeploys.OPERATOR_FEE_VAULT));
    IGasPriceOracle gasPriceOracle = IGasPriceOracle(Predeploys.GAS_PRICE_ORACLE);
    IL1Block l1Block = IL1Block(Predeploys.L1_BLOCK_ATTRIBUTES);
    IWETH98 weth = IWETH98(payable(Predeploys.WETH));
    IVerifier aggregateVerifier;
    TEEProverRegistry teeProverRegistry;

    /// @notice Indicates whether a test is running against a forked production network.
    function isForkTest() public view returns (bool) {
        return Config.forkTest();
    }

    /// @notice Indicates whether a test is running against a forked network that is OP.
    function isOpFork() public view returns (bool) {
        string memory opChain = Config.forkOpChain();
        return keccak256(bytes(opChain)) == keccak256(bytes("op"));
    }

    /// @dev Deploys either the SystemDeploy.s.sol or Fork.s.sol contract, by fetching the bytecode dynamically using
    ///      `vm.getDeployedCode()` and etching it into the state.
    ///      This enables us to avoid including the bytecode of those contracts in the bytecode of this contract.
    ///      If the bytecode of those contracts was included in this contract, then it will double
    ///      the compile time and bloat all of the test contract artifacts since they
    ///      will also need to include the bytecode for the SystemDeploy contract.
    ///      This is a hack as we are pushing solidity to the edge.
    function setUp() public virtual {
        console.log("Setup: L1 setup start!");

        if (isForkTest()) {
            vm.createSelectFork(Config.forkRpcUrl(), Config.forkBlockNumber());
            console.log("Setup: fork selected!");
            require(
                block.chainid == ETH_SEPOLIA_CHAIN_ID || block.chainid == ETH_MAINNET_CHAIN_ID,
                "Setup: ETH_RPC_URL must be set to a production (Sepolia or Mainnet) RPC URL"
            );
        }

        // Etch the contracts used to setup the test environment
        DeployUtils.etchLabelAndAllowCheatcodes({ _etchTo: address(deploy), _cname: "SystemDeploy" });
        DeployUtils.etchLabelAndAllowCheatcodes({ _etchTo: address(forkLive), _cname: "ForkLive" });

        deploy.setUp();

        console.log("Setup: L1 setup done!");

        if (isForkTest()) {
            // Return early if this is a fork test as we don't need to setup L2
            console.log("Setup: fork test detected, skipping L2 genesis generation");
            return;
        }

        console.log("Setup: L2 setup start!");
        vm.etch(address(l2Genesis), vm.getDeployedCode("L2Genesis.s.sol:L2Genesis"));
        vm.allowCheatcodes(address(l2Genesis));
        console.log("Setup: L2 setup done!");
    }

    /// @dev Skips tests when running in coverage mode.
    function skipIfCoverage() public {
        if (vm.isContext(VmSafe.ForgeContext.Coverage)) {
            vm.skip(true);
        }
    }

    /// @dev Skips tests when running against a forked production network.
    function skipIfForkTest(string memory message) public {
        if (isForkTest()) {
            vm.skip(true);
            console.log(string.concat("Skipping fork test: ", message));
        }
    }

    /// @dev Skips tests when running against a forked production network using the superchain ops repo.
    function skipIfOpsRepoTest(string memory message) public {
        if (forkLive.useOpsRepo()) {
            vm.skip(true);
            console.log(string.concat("Skipping ops repo test: ", message));
        }
    }

    /// @dev Returns early when running against a forked production network. Useful for allowing a portion of a test
    ///      to run.
    function returnIfForkTest(string memory message) public view {
        if (isForkTest()) {
            console.log(string.concat("Returning early from fork test: ", message));
            assembly {
                return(0, 0)
            }
        }
    }

    /// @dev Sets up the L1 contracts.
    function L1() public {
        console.log("Setup: creating L1 deployments");
        // Set the deterministic deployer in state to ensure that it is there
        vm.etch(
            0x4e59b44847b379578588920cA78FbF26c0B4956C,
            hex"7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffe03601600081602082378035828234f58015156039578182fd5b8082525050506014600cf3"
        );

        if (isForkTest()) {
            forkLive.run();
        } else {
            deploy.run();
        }

        console.log("Setup: completed L1 deployment, registering addresses now");

        optimismPortal2 = IOptimismPortal(artifacts.mustGetAddress("OptimismPortalProxy"));

        // Only skip ETHLockbox assignment if we're in a fork test with non-upgraded fork
        // TODO(#14691): Remove this check once Upgrade 15 is deployed on Mainnet.
        if (!isForkTest() || deploy.cfg().useUpgradedFork()) {
            // Here we use getAddress instead of mustGetAddress because some chains might not have
            // the ETHLockbox proxy. Chains that don't have the ETHLockbox proxy will just return
            // address(0) and cause a revert if we use mustGetAddress.
            ethLockbox = IETHLockbox(artifacts.getAddress("ETHLockboxProxy"));
        }

        systemConfig = ISystemConfig(artifacts.mustGetAddress("SystemConfigProxy"));
        l1StandardBridge = IL1StandardBridge(artifacts.mustGetAddress("L1StandardBridgeProxy"));
        l1CrossDomainMessenger = IL1CrossDomainMessenger(artifacts.mustGetAddress("L1CrossDomainMessengerProxy"));
        vm.label(
            AddressAliasHelper.applyL1ToL2Alias(address(l1CrossDomainMessenger)), "L1CrossDomainMessengerProxy_aliased"
        );
        addressManager = IAddressManager(artifacts.mustGetAddress("AddressManager"));
        l1ERC721Bridge = IL1ERC721Bridge(artifacts.mustGetAddress("L1ERC721BridgeProxy"));
        l1OptimismMintableERC20Factory =
            IOptimismMintableERC20Factory(artifacts.mustGetAddress("OptimismMintableERC20FactoryProxy"));
        superchainConfig = ISuperchainConfig(artifacts.mustGetAddress("SuperchainConfigProxy"));
        anchorStateRegistry = IAnchorStateRegistry(artifacts.mustGetAddress("AnchorStateRegistryProxy"));
        disputeGameFactory = IDisputeGameFactory(artifacts.mustGetAddress("DisputeGameFactoryProxy"));
        delayedWeth = IDelayedWETH(artifacts.mustGetAddress("DelayedWETHProxy"));
        proxyAdmin = IProxyAdmin(artifacts.mustGetAddress("ProxyAdmin"));
        proxyAdminOwner = proxyAdmin.owner();
        superchainProxyAdmin = IProxyAdmin(EIP1967Helper.getAdmin(address(superchainConfig)));
        superchainProxyAdminOwner = superchainProxyAdmin.owner();
        mips = IBigStepper(artifacts.mustGetAddress("MipsSingleton"));
        aggregateVerifier = IVerifier(artifacts.getAddress("AggregateVerifier"));
        teeProverRegistry = TEEProverRegistry(artifacts.getAddress("TEEProverRegistry"));

        console.log("Setup: registered L1 deployments");

        // Update the SystemConfig address.
        setSystemConfig(systemConfig);
    }

    /// @dev Sets up the L2 contracts. Depends on `L1()` being called first.
    function L2() public {
        // Fork tests focus on L1 contracts so there is no need to do all the work of setting up L2.
        if (isForkTest()) {
            console.log("Setup: fork test detected, skipping L2 setup");
            return;
        }

        console.log("Setup: creating L2 genesis with fork %s", l2Fork.toString());
        l2Genesis.run(
            L2Genesis.Input({
                l1ChainID: deploy.cfg().l1ChainId(),
                l2ChainID: deploy.cfg().l2ChainId(),
                l1CrossDomainMessengerProxy: payable(address(l1CrossDomainMessenger)),
                l1StandardBridgeProxy: payable(address(l1StandardBridge)),
                l1ERC721BridgeProxy: payable(address(l1ERC721Bridge)),
                opChainProxyAdminOwner: deploy.cfg().proxyAdminOwner(),
                sequencerFeeVaultRecipient: deploy.cfg().sequencerFeeVaultRecipient(),
                sequencerFeeVaultMinimumWithdrawalAmount: deploy.cfg().sequencerFeeVaultMinimumWithdrawalAmount(),
                sequencerFeeVaultWithdrawalNetwork: deploy.cfg().sequencerFeeVaultWithdrawalNetwork(),
                baseFeeVaultRecipient: deploy.cfg().baseFeeVaultRecipient(),
                baseFeeVaultMinimumWithdrawalAmount: deploy.cfg().baseFeeVaultMinimumWithdrawalAmount(),
                baseFeeVaultWithdrawalNetwork: deploy.cfg().baseFeeVaultWithdrawalNetwork(),
                l1FeeVaultRecipient: deploy.cfg().l1FeeVaultRecipient(),
                l1FeeVaultMinimumWithdrawalAmount: deploy.cfg().l1FeeVaultMinimumWithdrawalAmount(),
                l1FeeVaultWithdrawalNetwork: deploy.cfg().l1FeeVaultWithdrawalNetwork(),
                operatorFeeVaultRecipient: deploy.cfg().operatorFeeVaultRecipient(),
                operatorFeeVaultMinimumWithdrawalAmount: deploy.cfg().operatorFeeVaultMinimumWithdrawalAmount(),
                operatorFeeVaultWithdrawalNetwork: deploy.cfg().operatorFeeVaultWithdrawalNetwork(),
                fork: uint256(l2Fork),
                fundDevAccounts: deploy.cfg().fundDevAccounts()
            })
        );

        // L2 predeploys
        labelPredeploy(Predeploys.L2_STANDARD_BRIDGE);
        labelPredeploy(Predeploys.L2_CROSS_DOMAIN_MESSENGER);
        labelPredeploy(Predeploys.L2_TO_L1_MESSAGE_PASSER);
        labelPredeploy(Predeploys.SEQUENCER_FEE_WALLET);
        labelPredeploy(Predeploys.L2_ERC721_BRIDGE);
        labelPredeploy(Predeploys.OPTIMISM_MINTABLE_ERC721_FACTORY);
        labelPredeploy(Predeploys.BASE_FEE_VAULT);
        labelPredeploy(Predeploys.L1_FEE_VAULT);
        labelPredeploy(Predeploys.OPERATOR_FEE_VAULT);
        labelPredeploy(Predeploys.L1_BLOCK_ATTRIBUTES);
        labelPredeploy(Predeploys.GAS_PRICE_ORACLE);
        labelPredeploy(Predeploys.EAS);
        labelPredeploy(Predeploys.SCHEMA_REGISTRY);
        labelPredeploy(Predeploys.WETH);

        // L2 Preinstalls
        labelPreinstall(Preinstalls.MultiCall3);
        labelPreinstall(Preinstalls.Create2Deployer);
        labelPreinstall(Preinstalls.Safe_v130);
        labelPreinstall(Preinstalls.SafeL2_v130);
        labelPreinstall(Preinstalls.MultiSendCallOnly_v130);
        labelPreinstall(Preinstalls.SafeSingletonFactory);
        labelPreinstall(Preinstalls.DeterministicDeploymentProxy);
        labelPreinstall(Preinstalls.MultiSend_v130);
        labelPreinstall(Preinstalls.Permit2);
        labelPreinstall(Preinstalls.SenderCreator_v060);
        labelPreinstall(Preinstalls.EntryPoint_v060);
        labelPreinstall(Preinstalls.SenderCreator_v070);
        labelPreinstall(Preinstalls.EntryPoint_v070);
        labelPreinstall(Preinstalls.BeaconBlockRoots);
        labelPreinstall(Preinstalls.HistoryStorage);
        labelPreinstall(Preinstalls.CreateX);

        console.log("Setup: completed L2 genesis");
    }

    function labelPredeploy(address _addr) internal {
        vm.label(_addr, Predeploys.getName(_addr));
    }

    function labelPreinstall(address _addr) internal {
        vm.label(_addr, Preinstalls.getName(_addr));
    }
}
