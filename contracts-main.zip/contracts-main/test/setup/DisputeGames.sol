// SPDX-License-Identifier: MIT
pragma solidity 0.8.15;

// Testing
import { FeatureFlags } from "./FeatureFlags.sol";
import { ByteUtils } from "./ByteUtils.sol";
import { Vm } from "lib/forge-std/src/Vm.sol";
import { console2 as console } from "lib/forge-std/src/console2.sol";

// Libraries
import { GameType, Claim } from "src/libraries/bridge/LibUDT.sol";
import { GameTypes } from "src/libraries/bridge/Types.sol";
import { LibGameArgs } from "src/libraries/bridge/LibGameArgs.sol";

// Interfaces
import "../../interfaces/L1/proofs/IDisputeGame.sol";
import "../../interfaces/L1/proofs/IDisputeGameFactory.sol";
import { IPermissionedDisputeGameV2 } from "../../interfaces/L1/proofs/v2/IPermissionedDisputeGameV2.sol";

contract DisputeGames is FeatureFlags {
    using ByteUtils for bytes;

    /// @notice The address of the foundry Vm contract.
    Vm private constant vm = Vm(0x7109709ECfa91a80626fF3989D68f67F5b1DD12D);

    /// @notice Helper function to create a permissioned game through the factory
    function createGame(
        IDisputeGameFactory _factory,
        GameType _gameType,
        address _proposer,
        Claim _claim,
        uint256 _l2BlockNumber
    )
        internal
        returns (address)
    {
        // Check if there's an init bond required for the game type
        uint256 initBond = _factory.initBonds(_gameType);
        console.log("Init bond", initBond);

        // Fund the proposer if needed
        if (initBond > 0) {
            vm.deal(_proposer, initBond);
        }

        // We use vm.startPrank to set both msg.sender and tx.origin to the proposer
        vm.startPrank(_proposer, _proposer);

        IDisputeGame gameProxy =
            _factory.create{ value: initBond }(_gameType, _claim, abi.encode(bytes32(_l2BlockNumber)));

        vm.stopPrank();

        return address(gameProxy);
    }

    function isGamePermissioned(GameType _gameType) internal pure returns (bool) {
        return _gameType.raw() == GameTypes.PERMISSIONED_CANNON.raw()
            || _gameType.raw() == GameTypes.SUPER_PERMISSIONED_CANNON.raw();
    }

    enum GameArg {
        PRESTATE,
        VM,
        ASR,
        WETH,
        L2_CHAIN_ID,
        PROPOSER,
        CHALLENGER
    }

    /// @notice Thrown when an unsupported game arg is provided
    error DisputeGames_UnsupportedGameArg(GameArg gameArg);

    function gameArgsOffset(GameArg _gameArg) internal pure returns (uint256) {
        if (_gameArg == GameArg.PRESTATE) return 0;
        if (_gameArg == GameArg.VM) return 32;
        if (_gameArg == GameArg.ASR) return 52;
        if (_gameArg == GameArg.WETH) return 72;
        if (_gameArg == GameArg.L2_CHAIN_ID) return 92;
        if (_gameArg == GameArg.PROPOSER) return 124;
        if (_gameArg == GameArg.CHALLENGER) return 144;

        revert DisputeGames_UnsupportedGameArg(_gameArg);
    }

    function permissionedGameChallenger(IDisputeGameFactory _dgf) internal returns (address challenger_) {
        GameType gameType = GameTypes.PERMISSIONED_CANNON;
        (bool gameArgsExist, bytes memory gameArgsData) = _getGameArgs(_dgf, gameType);
        if (gameArgsExist) {
            LibGameArgs.GameArgs memory gameArgs = LibGameArgs.decode(gameArgsData);
            challenger_ = gameArgs.challenger;
        } else {
            challenger_ = IPermissionedDisputeGameV2(address(_dgf.gameImpls(gameType))).challenger();
        }
    }

    function permissionedGameProposer(IDisputeGameFactory _dgf) internal returns (address proposer_) {
        GameType gameType = GameTypes.PERMISSIONED_CANNON;
        (bool gameArgsExist, bytes memory gameArgsData) = _getGameArgs(_dgf, gameType);
        if (gameArgsExist) {
            LibGameArgs.GameArgs memory gameArgs = LibGameArgs.decode(gameArgsData);
            proposer_ = gameArgs.proposer;
        } else {
            proposer_ = IPermissionedDisputeGameV2(address(_dgf.gameImpls(gameType))).proposer();
        }
    }

    function mockGameImplPrestate(IDisputeGameFactory _dgf, GameType _gameType, bytes32 _prestate) internal {
        bytes memory value = abi.encodePacked(_prestate);
        _mockGameArg(_dgf, _gameType, GameArg.PRESTATE, value);
    }

    function mockGameImplVM(IDisputeGameFactory _dgf, GameType _gameType, address _vm) internal {
        bytes memory value = abi.encodePacked(_vm);
        _mockGameArg(_dgf, _gameType, GameArg.VM, value);
    }

    function mockGameImplASR(IDisputeGameFactory _dgf, GameType _gameType, address _asr) internal {
        bytes memory value = abi.encodePacked(_asr);
        _mockGameArg(_dgf, _gameType, GameArg.ASR, value);
    }

    function mockGameImplWeth(IDisputeGameFactory _dgf, GameType _gameType, address _weth) internal {
        bytes memory value = abi.encodePacked(_weth);
        _mockGameArg(_dgf, _gameType, GameArg.WETH, value);
    }

    function mockGameImplL2ChainId(IDisputeGameFactory _dgf, GameType _gameType, uint256 _chainId) internal {
        bytes memory value = abi.encodePacked(_chainId);
        _mockGameArg(_dgf, _gameType, GameArg.L2_CHAIN_ID, value);
    }

    function mockGameImplProposer(IDisputeGameFactory _dgf, GameType _gameType, address _proposer) internal {
        bytes memory value = abi.encodePacked(_proposer);
        _mockGameArg(_dgf, _gameType, GameArg.PROPOSER, value);
    }

    function mockGameImplChallenger(IDisputeGameFactory _dgf, GameType _gameType, address _challenger) internal {
        bytes memory value = abi.encodePacked(_challenger);
        _mockGameArg(_dgf, _gameType, GameArg.CHALLENGER, value);
    }

    function _getGameArgs(
        IDisputeGameFactory _dgf,
        GameType _gameType
    )
        private
        returns (bool gameArgsExist_, bytes memory gameArgs_)
    {
        bytes memory gameArgsCallData = abi.encodeCall(IDisputeGameFactory.gameArgs, (_gameType));
        (bool success, bytes memory gameArgs) = address(_dgf).call(gameArgsCallData);

        gameArgsExist_ = success && gameArgs.length > 0;
        gameArgs_ = gameArgsExist_ ? gameArgs : bytes("");
    }

    function _mockGameArg(IDisputeGameFactory _dgf, GameType _gameType, GameArg _gameArg, bytes memory _value) private {
        bytes memory modifiedGameArgs = _dgf.gameArgs(_gameType);
        uint256 offset = gameArgsOffset(_gameArg);
        modifiedGameArgs.overwriteAtOffset(offset, _value);

        vm.mockCall(
            address(_dgf), abi.encodeCall(IDisputeGameFactory.gameArgs, (_gameType)), abi.encode(modifiedGameArgs)
        );
    }
}
